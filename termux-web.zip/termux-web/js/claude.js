const CL={key:localStorage.ck||'',model:localStorage.cm||'claude-sonnet-5-5',msgs:[],ctl:null};

function claudeStart(a){
  const i=a.indexOf('--key');
  if(i>=0&&a[i+1]){CL.key=a[i+1];localStorage.ck=CL.key;a.splice(i,2)}
  mode='claude';term.classList.add('cc');
  print('╭──────────────────────────────────────╮','or');
  print('│ ✻ Welcome to Claude Code             │','or');
  print('╰──────────────────────────────────────╯','or');
  print('  cwd: '+tilde(cwd)+'\n  model: '+CL.model+'\n  /help untuk bantuan, /exit untuk keluar\n','dim');
  if(!CL.key)print('Belum ada API key. Ketik: /key sk-ant-xxxx\n(disimpan hanya di browser ini)','warn');
  if(a.length)return claudeLine(a.join(' '));
}

function claudeSys(){
  let n=0,b='';
  (function w(d,p){
    for(const k of Object.keys(d.c).sort()){
      const e=d.c[k],q=p+'/'+k;
      if(e.t=='d')w(e,q);
      else if(n++<60)b+='- '+q+(e.d.length<1500&&b.length<6000?'\n```\n'+e.d+'\n```':'')+'\n';
    }
  })(get(cwd),'.');
  return 'Kamu adalah Claude Code, asisten coding di emulator terminal Termux berbasis browser dengan sistem file virtual. '
   +'Balas ringkas, dalam bahasa yang dipakai pengguna. '
   +'Untuk membuat atau mengubah file, tulis blok persis seperti ini (path relatif terhadap cwd, isi file lengkap):\n'
   +'```file:path/nama.ext\nisi file\n```\n'
   +'Jangan pakai awalan "file:" untuk contoh kode biasa. Kamu tidak bisa menjalankan perintah; sarankan pengguna menjalankannya (mis. node app.js).\n'
   +'cwd: '+cwd+'\nFile saat ini:\n'+(b||'(kosong)');
}

async function claudeLine(v){
  v=v.trim();if(!v)return;
  if(v[0]=='/'){
    const [c,...r]=v.split(/\s+/);
    if(c=='/exit'||c=='/quit'){mode='shell';term.classList.remove('cc');print('Sampai jumpa!','dim');return}
    if(c=='/key'){CL.key=r[0]||'';localStorage.ck=CL.key;print(CL.key?'API key disimpan di browser ini.':'API key dihapus.','dim');return}
    if(c=='/model'){if(r[0]){CL.model=r[0];localStorage.cm=r[0]}print('Model: '+CL.model,'dim');return}
    if(c=='/clear'){CL.msgs=[];out.innerHTML='';return}
    if(c=='/help'){print('/key <apikey>   set API key\n/model <nama>  ganti model\n/clear         hapus percakapan\n/exit          kembali ke shell\n\nMinta Claude membuat file; otomatis ditulis ke folder aktif.\nPindah folder dulu dengan cd di shell.','dim');return}
    print('Perintah tidak dikenal. Ketik /help','err');return;
  }
  if(!CL.key){print('Set API key dulu: /key sk-ant-...','warn');return}
  const sp=print('✻ Thinking… (Ctrl+C untuk batal)','or');
  CL.ctl=new AbortController();
  CL.msgs.push({role:'user',content:v});
  try{
    const r=await fetch('https://api.anthropic.com/v1/messages',{
      method:'POST',signal:CL.ctl.signal,
      headers:{'content-type':'application/json','x-api-key':CL.key,'anthropic-version':'2023-06-01','anthropic-dangerous-direct-browser-access':'true'},
      body:JSON.stringify({model:CL.model,max_tokens:4000,system:claudeSys(),messages:CL.msgs})
    });
    const j=await r.json();
    if(!r.ok)throw Error((j.error&&j.error.message)||('HTTP '+r.status));
    const t=j.content.filter(b=>b.type=='text').map(b=>b.text).join('');
    CL.msgs.push({role:'assistant',content:t});
    sp.remove();
    const written=[];
    const rest=t.replace(/```file:([^\n]+)\n([\s\S]*?)```/g,(m,p,c)=>{
      p=p.trim();
      try{mkp(split(p)[0]);put(p,c);written.push([p,1])}catch(e){written.push([p+' ('+e.message+')',0])}
      return '';
    }).trim();
    if(rest)print('● '+rest);
    written.forEach(([p,ok])=>print(ok?'● Write('+tilde(abs(p))+')':'✗ '+p,ok?'ok':'err'));
    if(written.some(w=>w[1]))print('  File tersimpan. Ketik /exit lalu ls untuk melihatnya.','dim');
  }catch(e){
    sp.remove();CL.msgs.pop();
    print(e.name=='AbortError'?'Dibatalkan.':'Error: '+e.message,'err');
  }
  CL.ctl=null;
}
