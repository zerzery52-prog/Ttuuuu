const $=s=>document.querySelector(s),out=$('#out'),inp=$('#in'),ps=$('#ps'),term=$('#term');
const HOME='/data/data/com.termux/files/home',USER='u0_a123';
let cwd=HOME,mode='shell',hist=[],hi=0,ctrl=false,busy=false,editFile=null;
try{hist=JSON.parse(localStorage.th||'[]')}catch(e){}
let fs;try{fs=JSON.parse(localStorage.tfs)}catch(e){}
let inst=new Set(JSON.parse(localStorage.tp||'["bash","coreutils","nodejs","nano","grep"]'));
const sleep=ms=>new Promise(r=>setTimeout(r,ms));

/* ---------- filesystem virtual (disimpan di localStorage) ---------- */
function save(){localStorage.tfs=JSON.stringify(fs)}
function abs(p){p=p||'';if(p==='~'||p.startsWith('~/'))p=HOME+p.slice(1);if(p[0]!=='/')p=cwd+'/'+p;const o=[];for(const s of p.split('/')){if(!s||s==='.')continue;s==='..'?o.pop():o.push(s)}return '/'+o.join('/')}
function get(p){let n=fs;for(const s of abs(p).split('/').filter(Boolean)){if(!n||n.t!=='d'||!n.c[s])return null;n=n.c[s]}return n}
function split(p){const a=abs(p),i=a.lastIndexOf('/');return [a.slice(0,i)||'/',a.slice(i+1)]}
function mkp(p){let n=fs;for(const s of abs(p).split('/').filter(Boolean))n=n.c[s]=n.c[s]||{t:'d',c:{}};save()}
function put(p,d,app){const [dir,name]=split(p),D=get(dir);if(!D||D.t!=='d')throw Error(p+': No such file or directory');const e=D.c[name];if(e&&e.t==='d')throw Error(p+': Is a directory');D.c[name]={t:'f',d:(app&&e?e.d:'')+d};save()}
function rd(p){const n=get(p);if(!n)throw Error(p+': No such file or directory');if(n.t==='d')throw Error(p+': Is a directory');return n.d}
function tilde(p){return p===HOME?'~':p.startsWith(HOME+'/')?'~'+p.slice(HOME.length):p}
if(!fs){fs={t:'d',c:{}};mkp(HOME);mkp('/data/data/com.termux/files/usr/bin');
  put(HOME+'/hello.js','console.log("Halo dari Termux web!");\n');
  put(HOME+'/README.md','# Termux Web\n\nKetik `help` untuk daftar perintah,\natau `claude` untuk membuka Claude Code.\n')}

/* ---------- output ---------- */
function print(t='',c=''){const d=document.createElement('div');d.className=c;
  String(t).split(/(\u0001[^\u0002]*\u0002)/).forEach(p=>{if(p[0]==='\u0001'){const s=document.createElement('span');s.className='dir';s.textContent=p.slice(1,-1);d.append(s)}else d.append(p)});
  out.append(d);term.scrollTop=term.scrollHeight;return d}
const strip=t=>t.replace(/[\u0001\u0002]/g,'');
function setPs(){ps.textContent=mode==='claude'?'> ':tilde(cwd)+' $ '}

/* ---------- perintah ---------- */
const D=x=>'\u0001'+x+'\u0002';
function tree(n,pre=''){const k=Object.keys(n.c).sort();return k.map((x,i)=>{const l=i==k.length-1,e=n.c[x];return pre+(l?'└── ':'├── ')+(e.t=='d'?D(x):x)+(e.t=='d'?'\n'+tree(e,pre+(l?'    ':'│   ')):'')}).join('\n').replace(/\n$/,'')}
function edit(f){editFile=f;mode='editor';const n=get(f);$('#et').textContent='GNU nano  '+f;$('#ea').value=n&&n.t=='f'?n.d:'';$('#ed').hidden=false;$('#ea').focus()}
function closeEd(){$('#ed').hidden=true;mode='shell';setPs();inp.focus()}
const flags=a=>a.filter(x=>x[0]=='-'&&x.length>1).join(''),files=a=>a.filter(x=>x[0]!='-'||x=='-');

const C={
help(){return 'Perintah: ls cd pwd cat echo mkdir touch rm cp mv tree grep head wc\nnano vim node pkg apt which history date uname whoami neofetch clear claude\n\nTips: gunakan > dan >> untuk redirect, | untuk pipe, TAB untuk melengkapi nama.'},
clear(){out.innerHTML=''},
pwd(){return cwd},
whoami(){return USER},
date(){return new Date().toString()},
uname(a){return a.includes('-a')?'Linux localhost 5.15.0-android13 #1 SMP PREEMPT aarch64 Android':'Linux'},
echo(a){return a.join(' ')},
which(a){return C[a[0]]?'/data/data/com.termux/files/usr/bin/'+a[0]:''},
history(){return hist.map((h,i)=>String(i+1).padStart(5)+'  '+h).join('\n')},
ls(a){const f=flags(a),p=files(a)[0]||'.',n=get(p);if(!n)throw Error(`ls: cannot access '${p}': No such file or directory`);if(n.t=='f')return p;
  let k=Object.keys(n.c).sort();if(!f.includes('a'))k=k.filter(x=>x[0]!='.');
  const nm=x=>n.c[x].t=='d'?D(x):x;
  if(f.includes('l'))return 'total '+k.length+'\n'+k.map(x=>{const e=n.c[x];return (e.t=='d'?'drwx------':'-rw-------')+` 1 ${USER} ${USER} ${String(e.t=='d'?4096:e.d.length).padStart(5)} ${new Date().toLocaleDateString('en',{month:'short',day:'2-digit'})} ${nm(x)}`}).join('\n');
  return k.map(nm).join('  ')},
cd(a){const p=a[0]||'~',n=get(p);if(!n)throw Error(`cd: ${p}: No such file or directory`);if(n.t!='d')throw Error(`cd: ${p}: Not a directory`);cwd=abs(p)},
cat(a,s){return a.length?a.map(rd).join(''):s||''},
mkdir(a){const p=flags(a).includes('p');for(const x of files(a)){if(get(x)&&!p)throw Error(`mkdir: cannot create directory '${x}': File exists`);if(!p&&!get(split(x)[0]))throw Error(`mkdir: cannot create directory '${x}': No such file or directory`);mkp(x)}},
touch(a){for(const x of files(a))if(!get(x))put(x,'')},
rm(a){const r=/[rR]/.test(flags(a));for(const x of files(a)){const n=get(x);if(!n)throw Error(`rm: cannot remove '${x}': No such file or directory`);if(n.t=='d'&&!r)throw Error(`rm: cannot remove '${x}': Is a directory`);const [d,k]=split(x);delete get(d).c[k]}save()},
cp(a,s,mv){const f=files(a),[src,dst]=f,n=get(src);if(f.length<2)throw Error('missing destination');if(!n)throw Error(`cannot stat '${src}': No such file or directory`);
  let t=dst;const g=get(dst);if(g&&g.t=='d')t=dst+'/'+split(src)[1];const [d,k]=split(t),P=get(d);if(!P)throw Error(`cannot create '${dst}'`);
  P.c[k]=JSON.parse(JSON.stringify(n));if(mv){const [sd,sk]=split(src);if(sd+'/'+sk!==d+'/'+k)delete get(sd).c[sk]}save()},
mv(a){return C.cp(a,0,1)},
tree(a){const n=get(a[0]||'.');if(!n||n.t!='d')throw Error('tree: not a directory');return D(a[0]||'.')+'\n'+tree(n)},
head(a,s){let n=10;const i=a.indexOf('-n');if(i>=0){n=+a[i+1];a.splice(i,2)}const f=files(a)[0];return (f?rd(f):s||'').split('\n').slice(0,n).join('\n')},
wc(a,s){const f=files(a)[0],t=f?rd(f):s||'';return `${(t.match(/\n/g)||[]).length} ${t.split(/\s+/).filter(Boolean).length} ${t.length} ${f||''}`.trim()},
grep(a,s){const i=flags(a).includes('i'),f=files(a),re=new RegExp(f[0],i?'i':''),t=f[1]?rd(f[1]):s||'';return t.split('\n').filter(l=>re.test(l)).join('\n')},
nano(a){if(!a[0])throw Error('Usage: nano <file>');edit(a[0])},
async pkg(a){const [s,...p]=a;
  if(s=='install'||s=='i'){if(!p.length)throw Error('Usage: pkg install <paket>');for(const x of p){print('Get:1 https://packages.termux.dev stable/main aarch64 '+x+' [1.204 kB]','dim');await sleep(450);print('Unpacking '+x+' ...');await sleep(350);print('Setting up '+x+' ...');inst.add(x)}localStorage.tp=JSON.stringify([...inst]);return}
  if(s=='update'||s=='upgrade'){print('Hit:1 https://packages.termux.dev stable InRelease','dim');await sleep(500);return 'All packages are up to date.'}
  if(s=='list-installed')return [...inst].sort().join('\n');
  if(s=='uninstall'||s=='remove'){p.forEach(x=>inst.delete(x));localStorage.tp=JSON.stringify([...inst]);return}
  return 'Usage: pkg install|update|upgrade|list-installed|uninstall'},
node(a){if(!inst.has('nodejs'))throw Error('node: command not found. Jalankan: pkg install nodejs');
  const e=a.indexOf('-e'),code=e>=0?a[e+1]:rd(a[0]);let o=[];const fmt=x=>typeof x=='string'?x:JSON.stringify(x);
  const con={log:(...x)=>o.push(x.map(fmt).join(' ')),error:(...x)=>o.push(x.map(fmt).join(' ')),warn:(...x)=>o.push(x.map(fmt).join(' '))};
  try{new Function('console',code)(con)}catch(x){o.push(x.name+': '+x.message)}return o.join('\n')},
neofetch(){return `${USER}@localhost\n-----------------\nOS: Android 13 aarch64\nHost: Termux Web\nKernel: 5.15.0-android13\nShell: bash 5.2\nPackages: ${inst.size} (pkg)\nTerminal: termux-web`},
claude(a){return claudeStart(a)}
};
C.vim=C.vi=C.nano;C.apt=C['apt-get']=C.pkg;C.ll=a=>C.ls(['-l',...a]);

/* ---------- eksekusi baris perintah ---------- */
const tok=s=>(s.match(/"[^"]*"|'[^']*'|[^\s]+/g)||[]).map(x=>x.replace(/^(["'])(.*)\1$/,'$2').replace(/\$(HOME|PWD|USER)/g,(_,v)=>({HOME,PWD:cwd,USER}[v])));
async function exec(line){let data;
  for(const seg of line.split(/\s+\|\s+/)){const t=tok(seg);if(!t.length)continue;let red=null,app=false;
    const k=t.findIndex(x=>x[0]=='>');if(k>=0){app=t[k].startsWith('>>');const r=t[k].replace(/^>>?/,'');red=r||t[k+1];t.splice(k,r?1:2)}
    const [c,...a]=t,f=C[c];if(!f){print(`bash: ${c}: command not found`,'err');return}
    try{data=await f(a,data&&strip(data))}catch(e){print(e.message,'err');return}
    data=data==null?'':String(data);
    if(red){try{put(red,strip(data)+(data&&!data.endsWith('\n')?'\n':''),app)}catch(e){print(e.message,'err');return}data=''}}
  if(data)print(data.replace(/\n$/,''))}

/* ---------- input ---------- */
function tab(){const v=inp.value,m=v.match(/(\S*)$/)[1],i=m.lastIndexOf('/'),pre=m.slice(i+1),n=get(m.slice(0,i+1)||'.');if(!n||n.t!='d')return;
  const c=Object.keys(n.c).filter(x=>x.startsWith(pre));
  if(c.length==1)inp.value=v.slice(0,v.length-pre.length)+c[0]+(n.c[c[0]].t=='d'?'/':' ');else if(c.length>1)print(c.join('  '),'dim')}
inp.addEventListener('keydown',async e=>{
  const k=e.key,c=e.ctrlKey||ctrl;ctrl=false;document.querySelector('[data-k=CTRL]').classList.remove('on');
  if(c&&k=='c'){e.preventDefault();print(ps.textContent+inp.value+'^C',mode=='claude'?'or':'');inp.value='';if(CL.ctl)CL.ctl.abort();return}
  if(c&&k=='l'){e.preventDefault();out.innerHTML='';return}
  if(k=='Tab'){e.preventDefault();if(mode=='shell')tab();return}
  if(k=='ArrowUp'||k=='ArrowDown'){e.preventDefault();hi=Math.max(0,Math.min(hist.length,hi+(k=='ArrowUp'?-1:1)));inp.value=hist[hi]||'';return}
  if(k!='Enter'||busy)return;
  e.preventDefault();const v=inp.value;inp.value='';print(ps.textContent+v,mode=='claude'?'or':'');
  busy=true;
  if(mode=='claude')await claudeLine(v);
  else if(v.trim()){hist.push(v);localStorage.th=JSON.stringify(hist.slice(-200));hi=hist.length;await exec(v)}
  busy=false;setPs();term.scrollTop=term.scrollHeight});

document.querySelectorAll('#keys button').forEach(b=>b.onclick=()=>{const k=b.dataset.k;inp.focus();
  const key=n=>inp.dispatchEvent(new KeyboardEvent('keydown',{key:n,cancelable:true}));
  if(k=='CTRL'){ctrl=!ctrl;b.classList.toggle('on',ctrl)}
  else if(k=='UP')key('ArrowUp');else if(k=='DOWN')key('ArrowDown');else if(k=='TAB')key('Tab');
  else if(k=='LEFT')inp.selectionStart=inp.selectionEnd=Math.max(0,inp.selectionStart-1);
  else if(k=='RIGHT')inp.selectionStart=inp.selectionEnd=inp.selectionStart+1;
  else if(k=='HOME')inp.selectionStart=inp.selectionEnd=0;
  else if(k=='END')inp.selectionStart=inp.selectionEnd=inp.value.length;
  else if(k=='PGUP')term.scrollTop-=term.clientHeight*.8;else if(k=='PGDN')term.scrollTop+=term.clientHeight*.8;
  else if(k=='ESC'){if(mode=='claude')print('(ketik /exit untuk keluar dari Claude Code)','dim')}
  else if(k!='ALT'){const s=inp.selectionStart;inp.value=inp.value.slice(0,s)+k+inp.value.slice(s);inp.selectionStart=inp.selectionEnd=s+1}});

/* editor nano */
$('#es').onclick=()=>{try{put(editFile,$('#ea').value)}catch(e){alert(e.message)}};
$('#ex').onclick=closeEd;
$('#ea').addEventListener('keydown',e=>{if(e.ctrlKey&&e.key=='s'){e.preventDefault();$('#es').click()}if(e.ctrlKey&&e.key=='x'){e.preventDefault();closeEd()}});
term.addEventListener('click',()=>{if(!getSelection().toString())inp.focus()});

/* ---------- sambutan ---------- */
print('Welcome to Termux!\n\nDocs:       https://termux.dev/docs\nCommunity:  https://termux.dev/community\n\nWorking with packages:\n - Search:  pkg search <query>\n - Install: pkg install <package>\n - Upgrade: pkg upgrade\n\nKetik `claude` untuk membuka Claude Code, `help` untuk bantuan.\n');
setPs();inp.focus();
